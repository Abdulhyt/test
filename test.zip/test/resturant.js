var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function (err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var resturant = [
        { name: 'hasina', log: 11.7102, lat: 9.3357, address:"Abdullahi Mai kano way dutse" },
        { name: 'shemars', log: 11.7024, lat: "9.3340", address:"investment dutse" },
        { name: 'zulaihat', log: "15.00", lat: "11.00", address:"SLUK" }
      ];
    dbo.collection("resturant").insertMany(resturant, function (err, result) {
        if (err) throw err;
        console.log("recordss inserted");
        db.close();
    });
});
